<template>
    <span class="text-danger">*</span>
</template>
